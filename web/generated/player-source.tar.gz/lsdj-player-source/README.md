# LSDj Player browser exporter: corresponding source

This archive contains the exact project source for the public browser exporter,
its native display/bootstrap patches, and the pinned SameBoy core and replacement
boot-ROM source used by its WebAssembly startup capture. It contains no LSDj ROM,
user save, song, sample kit, recovered interpreter, or private startup snapshot.

Project code is GPL-2.0-or-later (LICENSE). SameBoy is Expat-licensed
(reference/SameBoy/LICENSE). The published browser credits are web/LICENSES.txt.
SOURCE_MANIFEST.json records all source-file SHA-256 hashes. SameBoy's exported
SOURCE_MANIFEST.json records its pinned upstream revision and source hashes;
no Git checkout is required to rebuild this archive.

web/player-cgb.png is the website's native-resolution CGB emulator screenshot.
Its PNG hash and capture provenance are recorded in web/player-cgb.json.

## Build the public website

Install Python 3.10 or later, GNU Make, a host C compiler, RGBDS (including
rgbasm, rgblink, rgbfix and rgbgfx), and Emscripten. The published build used
Emscripten 6.0.5 and SameBoy 1.0.3 at revision
c458e7c5d2d350fb37a1931c40da9f758d28d240.

From this directory, run:

    python3 tools/build_web_templates.py
    python3 tools/build_web_emulator.py
    python3 tools/package_web_source.py
    python3 tools/check_web_assets.py
    python3 -m http.server 8000 --directory web

Open http://localhost:8000/. The public patch templates are compiled exclusively
from zero-filled synthetic inputs. The WebAssembly module embeds SameBoy's free
replacement boot ROMs compiled from the included assembly. Neither build command
requires LSDj or a song. A user supplies those inputs locally in their browser
when exporting a player; no upload service is used.

The native engine remains experimental: generated-player audio has not yet
passed strict bit-exact comparison against LSDj. This source archive makes no
additional claim about playback equivalence.
